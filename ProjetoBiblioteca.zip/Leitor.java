public class Leitor extends Pessoa {
    private int matricula;

    public Leitor(String nome, String cpf, int matricula) {
        super(nome, cpf);
        this.matricula = matricula;
    }

    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Matrícula: " + matricula);
    }
}