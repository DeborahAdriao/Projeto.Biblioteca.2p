import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private static List<Livro> livros = new ArrayList<>();

    public static void adicionarLivro(Livro livro) {
        livros.add(livro);
    }

    public static void listarLivros() {
        for (Livro livro : livros) {
            livro.exibirDetalhes();
        }
    }
}